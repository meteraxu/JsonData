import console

manner = console.console_manner

if __name__ == "__main__":
    manner()